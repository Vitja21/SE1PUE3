package JUnitTest;

import static org.junit.jupiter.api.Assertions.fail;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class SpielbrettTest {

    @Test
    void test() {
        Assertions.fail("Not yet implemented");
    }

}