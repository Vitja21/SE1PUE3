package spieler;

public class Mensch extends Spieler {

    public Mensch(int nummer) {
	super(nummer);
    }

    private int[] koordZuFeldIndex(String koord) {
	int[] feldindex = new int[2];
	return feldindex;
    }

    private void waehleBewegung() {

    }

    private void waehleAngriff() {

    }

}