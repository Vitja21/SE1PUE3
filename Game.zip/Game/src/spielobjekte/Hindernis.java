package spielobjekte;

public final class Hindernis extends Spielobjekt {

    public Hindernis() {
        super('#');
    }
}