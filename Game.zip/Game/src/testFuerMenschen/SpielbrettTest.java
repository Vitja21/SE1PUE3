package testFuerMenschen;

import prototypen.Spiel;

public class SpielbrettTest {

    public static void main(final String[] args) {
        String[] arg = { "DEBUG" };
        Spiel.main(arg);
    }
}